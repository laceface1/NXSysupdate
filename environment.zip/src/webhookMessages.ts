import webhook from 'webhook-discord'

export const majorUpdate = ({ url }: { url: string }) =>
	new webhook.MessageBuilder()
		.setName('Packs')
		.setText('New major sysupdate detected!')
		.setColor('#b40a86')
		.setTime()
		.setURL(url)

// .setTitle(name)
// .setDescription(description)
// .setAuthor(name, iconurl, creator_page_url)
// .addField('Themes in this pack:', string)
// .setThumbnail(thumbnailURL)
// .setURL(url)

export const minorUpdate = new webhook.MessageBuilder()
	.setName('Themes')
	.setText('New Theme submission!')
	.setColor('#0ab379')
	.setTime()

export const patchUpdate = new webhook.MessageBuilder()
	.setName('Themes')
	.setText('New Theme submission!')
	.setColor('#0ab379')
	.setTime()

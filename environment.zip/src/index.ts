process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0'
import axios from 'axios'
const axiosCookieJarSupport = require('axios-cookiejar-support').default
const tough = require('tough-cookie')
axiosCookieJarSupport(axios)
const cookieJar = new tough.CookieJar()

import https from 'https'
import { readFileSync } from 'fs'

class SysUpdateHandler {
	SUN_URL: string
	SUN_NAME: string
	SERVER_ENV: string
	DEVICE_ID: string
	FIRMWARE_VERSION: string
	PLATFORM: string

	cert: string
	session: any

	constructor() {
		this.SUN_URL = 'https://sun.hac.lp1.d4c.nintendo.net/v1'
		this.SUN_NAME = 'sun'
		this.SERVER_ENV = 'lp1'
		this.DEVICE_ID = 'DEADBABECAFEBABE'
		this.FIRMWARE_VERSION = '5.1.0-3'
		this.PLATFORM = 'NX'
	}

	init(
		cert_loc: string = `${__dirname}/../../nx_tls_client_cert.pem`,
		device_id: string = null,
		server: string = null,
		env: string = null,
		fw_ver: string = null,
		platform: string = null
	) {
		this.cert = cert_loc
		this.init_session()
	}

	init_session() {
		var agent = new https.Agent({
			cert: readFileSync(this.cert),
			rejectUnauthorized: false,
		})

		this.session = axios.create({ httpsAgent: agent, jar: new tough.CookieJar() } as any)
		this.session.defaults.headers.common[
			'User-Agent'
		] = `NintendoSDK Firmware/${this.FIRMWARE_VERSION} (platform:${this.PLATFORM}; did:${this.DEVICE_ID}; eid:${this.SERVER_ENV})`
	}

	async get_latest_update() {
		try {
			const result = await this.session.get(`${this.SUN_URL}/system_update_meta?device_id=${this.DEVICE_ID}`, {
				jar: cookieJar,
				withCredentials: true,
			})
			console.log(result)
		} catch (e) {
			console.error(e, '--------ERROR--------')
		}
	}
}

const ctx = new SysUpdateHandler()

const main = () => {
	ctx.init()
	ctx.get_latest_update()
}

main()

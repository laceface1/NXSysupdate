process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0'
import axios from 'axios'
import https from 'https'
import { readFileSync } from 'fs'

import webhook from 'webhook-discord'
import { webhookUrls } from '../config'
import { majorUpdate, minorUpdate, patchUpdate } from './webhookMessages'
const hooks = webhookUrls.map((url) => new webhook.Webhook(url))

import editJsonFile from 'edit-json-file'
const file = editJsonFile('../data.json')

class SysUpdateHandler {
	CDN_URL_BASE: string
	SUN_URL_BASE: string
	CDN_URL: string
	SUN_URL: string
	CDN_NAME: string
	SUN_NAME: string
	CDN_TEMPLATE: string
	SERVER_SET: string
	SERVER_ENV: string
	DEVICE_ID: string
	FIRMWARE_VERSION: string
	PLATFORM: string
	CHUNK_SIZE: number

	cert: string
	agent: any
	session: any

	constructor() {
		this.CDN_URL_BASE = 'https://{}.hac.{}.{}.nintendo.net'
		this.SUN_URL_BASE = 'https://{}.hac.{}.{}.nintendo.net/v1'
		this.CDN_URL = 'https://atumn.hac.lp1.d4c.nintendo.net'
		this.SUN_URL = 'https://sun.hac.lp1.d4c.nintendo.net/v1'
		this.CDN_NAME = 'atumn'
		this.SUN_NAME = 'sun'
		this.CDN_TEMPLATE = '{}/t/{}/{}/{}?device_id={}'
		this.SERVER_SET = 'd4c'
		this.SERVER_ENV = 'lp1'
		this.DEVICE_ID = 'DEADBABECAFEBABE'
		this.FIRMWARE_VERSION = '5.1.0-3'
		this.PLATFORM = 'NX'
		this.CHUNK_SIZE = 0x40000
	}

	init(
		cert_loc: string = `${__dirname}/../../nx_tls_client_cert.pem`,
		device_id: string = null,
		server: string = null,
		env: string = null,
		fw_ver: string = null,
		platform: string = null
	) {
		this.cert = cert_loc
		if (device_id) this.DEVICE_ID = device_id
		if (env) this.SERVER_ENV = env
		if (server) this.SERVER_SET = server
		if (fw_ver) this.FIRMWARE_VERSION = fw_ver
		if (platform) this.PLATFORM = platform
		this.init_session()
	}

	init_session() {
		this.agent = new https.Agent({
			cert: readFileSync(this.cert),
		})

		this.session = (url, callback) => {
			https.get(
				url,
				{
					agent: this.agent,
					headers: {
						'user-agent': `NintendoSDK Firmware/${this.FIRMWARE_VERSION} (platform:${this.PLATFORM}; did:${this.DEVICE_ID}; eid:${this.SERVER_ENV})`,
					},
				},
				callback
			)
		}
	}

	async get_latest_update() {
		this.session(`${this.SUN_URL}/system_update_meta?device_id=${this.DEVICE_ID}`, (resp) => {
			let data = ''

			resp.on('data', (chunk) => {
				data += chunk
			})

			resp.on('end', () => {
				console.log(JSON.parse(data).explanation)
			})
		})
	}

	print_latest_sys_version() {
		this.get_latest_update()
	}
}

const ctx = new SysUpdateHandler()

const main = async () => {
	ctx.init()

	ctx.print_latest_sys_version()
}

main()

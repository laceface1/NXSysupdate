export const webhookUrls = [
	// PindyPlays
	'https://discordapp.com/api/webhooks/732539126678552616/_Y4wwBcRWu8stOe95UGEjdJPSoM62PUAxaaQukuJZdjSMR1Iw1Syo3rrcY0hmjrXAifa',
]
